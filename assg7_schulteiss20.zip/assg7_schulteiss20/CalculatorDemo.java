/*
 * @author Sariah Schulteis
 * This class gets an input from user and tests the methods in Calculator class
 */
package assg7_schulteiss20;

import java.util.Scanner;

public class CalculatorDemo {
	public static void main(String[] args) throws IllegalStateException {

		do {
			System.out.println("Enter an infix expression:");
			Scanner keyboard = new Scanner(System.in);
			String input = keyboard.nextLine();
			Calculator exp = new Calculator(input);
			System.out.println("Infix Expression:" + input);
			System.out.println("Postfix Expression:" + exp.getPostfix());
			System.out.println("Postfix Expression Evaluate:" + exp.evaluate());
			System.out.println("");
			System.out.println("Press y and enter for a new infix or press n and enter to stop.");
			Scanner keyboard1 = new Scanner(System.in);
			String input1 = keyboard.next();
			if ("N".equalsIgnoreCase(input1)) {
				System.exit(0);
			}
		} while (true);
	}
}
