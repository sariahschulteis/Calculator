/*
 * @author Sariah Schulteis
 * A class that changes an infix expression to postfix and evaluates the postfix expression
 */
package assg7_schulteiss20;

import java.util.Stack;

public class Calculator {

	public Stack<Character> charStore = new Stack<>();
	public Stack<Double> doubStore = new Stack<>();
	public String postfix = "";
	public String infix = "";
	public Character openParenthesis;

	/*
	 * Constructor for the Calculator class
	 * 
	 * @param infix expression
	 */
	public Calculator(String exp) {
		this.infix = exp;
	}

	/*
	 * @Override
	 * 
	 * @return string of the infix
	 */
	public String toString() {
		return this.infix;
	}

	/*
	 * Returns true if infix is converted to postfix correctly
	 * 
	 * @return true if infix is converted to postfix correctly
	 * 
	 * @return false if infix doesn't have the same number of parenthesis or if
	 * infix ends with +, -, *, or /
	 */
	private boolean convertPostfix() {
		int parenthesis = 0;
		int parenthesis2 = 0;
		int operand = 0;
		this.infix = " " + this.infix;
		char[] charArray = infix.toCharArray();
		int count = -1;

		for (Character ch : charArray) {
			switch (ch) {
			case '1', '2', '3', '4', '5', '6', '7', '8', '9', '0':
				operand++;

				if ((int) charArray[count] > 47 && (int) charArray[count] < 58)

					postfix = postfix + ch;
				else

					postfix = postfix + " " + ch;

				break;
			case ')':
				while (charStore.peek() != '(') {
					postfix = postfix + " " + charStore.pop();
				}

				openParenthesis = charStore.pop();

				parenthesis2++;
				break;
			case '(':
				charStore.push(ch);
				parenthesis++;
				break;
			
			case '+', '-', '*', '/':
				while (!charStore.isEmpty() && charStore.peek() != '(' && prec(ch) <= prec(charStore.peek())) {

					postfix = postfix + " " + charStore.pop();

				}
				charStore.push(ch);
				break;
			}
			count++;
		}

		while (!charStore.isEmpty()) {
			postfix = postfix + " " + charStore.pop();
		}

		if (parenthesis != parenthesis2 || charArray[charArray.length - 1] == '+'
				|| charArray[charArray.length - 1] == '-' || charArray[charArray.length - 1] == '*'
				|| charArray[charArray.length - 1] == '/' || operand == 0) {
			return false;
		}

		return true;
	}

	/*
	 * @return postfix expression
	 * 
	 * @throws IllegalStateException if false
	 */
	public String getPostfix() throws IllegalStateException {
		if (convertPostfix() == true) {
			return postfix;
		}
		throw new IllegalStateException();
	}

	/*
	 * Evaluates postfix
	 * 
	 * @return postfix that is evaluated
	 * 
	 * @throws IllegalStateException if false
	 */
	public Double evaluate() throws IllegalStateException {
		char[] charArray = postfix.toCharArray();
		if (convertPostfix() == true) {
			int count1 = 0;
			int count2 = 0;
			int count3 = 0;
			double solution = 0;
			for (char c : charArray) {
				count2 = count1;

				if (Character.isDigit(c)) {
					if (count2 + 1 != charArray.length && Character.isDigit(charArray[count2 + 1])) {
						count3++;
					} else {
						if (count3 > 0) {
							while (count3 > -1) {
								solution += ((charArray[count2 - count3] - '0') * Math.pow(10, count3));
								count3--;
							}
							doubStore.push(solution);
						} else
							doubStore.push((double) (c - '0'));
						solution = 0;
						count3 = 0;
					}
				}

				if (c == '*' || c == '-' || c == '+' || c == '/') {

					double x = doubStore.pop();
					double y = doubStore.pop();

					if (c == '*') {
						doubStore.push(y * x);
					} else if (c == '/') {
						doubStore.push(y / x);
					} else if (c == '+') {
						doubStore.push(y + x);
					} else if (c == '-') {
						doubStore.push(y - x);

					}
				}
				count1++;
			}
			return doubStore.pop();
		}
		throw new IllegalStateException();
	}

	/*
	 * @param c, the character which I am looking for the operators, +, -, *, /
	 * 
	 * @return precedence value of the operators
	 */
	private int prec(char c) {
		if (c == '+' || c == '-')
			return 1;
		else if (c == '*' || c == '/')
			return 2;
		else
			return -1;
	}

}